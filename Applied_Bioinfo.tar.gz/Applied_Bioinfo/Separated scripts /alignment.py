#!/usr/bin/env python3
# -*- coding: utf-8 -*
#MIT License
#Copyright (c) 2017 Maria Araceli Diaz Cruz

from glob import glob
for filename in glob('VDR_species1.fa'):
    with open(filename) as f:
	       output = str(filename)
	       output += 'a'
	       in_file = str(filename)
from Bio.Align.Applications import MafftCommandline
mafft_cline = MafftCommandline(input = in_file)
print(mafft_cline)
stdout, stderr = mafft_cline()
with open(output, 'w') as handle:
	    handle.write(stdout.upper())
