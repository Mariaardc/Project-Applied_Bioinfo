#!/usr/bin/env python3
# -*- coding: utf-8 -*

#open and close alignment file

from Bio import AlignIO
alignment= AlignIO.read('VDR_species1.faa','fasta')
#print(alignment)

#Summary of the sequence

from Bio.Align import AlignInfo
summary_align = AlignInfo.SummaryInfo(alignment)
#print (summary_align)

#Consensus sequence

consensus = summary_align.dumb_consensus(ambiguous='-')
print(consensus)

#position specific score matrix (representation of the motifs in our sequence, counting nucleotides in each column)

# Matrix based in the consensus sequence but excluding N residues:

my_pssm = summary_align.pos_specific_score_matrix(consensus,chars_to_ignore = ['N'])
with open('output7.txt', 'w') as output:
    print (my_pssm, file=output) #prints to output file
    print (my_pssm)


#Specific position of nucleotide:
#print (my_pssm[1]["A"])
