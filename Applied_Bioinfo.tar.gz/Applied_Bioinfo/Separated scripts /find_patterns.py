#!/usr/bin/env python3
# -*- coding: utf-8 -*

#MIT License
#Copyright (c) 2017 Maria Araceli Diaz Cruz


#Storing the variables into two lists: line in lines and nucleotides in nucleotides.

lines=[]
a =0
nucleotides=[]


f = open('sequences1.fa', 'wt')               #output file where the sequences selected are going to be stored.
with open('output.txt', 'r') as InFile: 
    InFile.readline()                        #skip first line
    for line in InFile:
        a=a+1                                #line counter
        line = line.strip('\n')
        lines=line                           #store each line in lines (list)
        if '-' not in line and '5.0' in line: #condition 1

            nucleotides.append(lines[0])      # append nucleotides which are in the first column.

        else:
            if len(nucleotides)>15:           #Second condition. If the intron is shorter change the condition to less restrictive (>10).
                b=a-len(nucleotides)+1
                print('')
                print('',file=f)
                print('>',b,'-',a)
                print('>',b,'-',a,file=f)
                print(''.join(nucleotides))
                print(''.join(nucleotides),file=f)
                del nucleotides[:]                    #Delete the list when sequences are stored.
            else:

                del nucleotides[:]                    # No sequences that reach the condition. Delete the list.
