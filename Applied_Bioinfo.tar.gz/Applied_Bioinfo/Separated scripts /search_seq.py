#!/usr/bin/env python3
# -*- coding: utf-8 -*

#MIT License
#Copyright (c) 2017 Maria Araceli Diaz Cruz

#Extract the hits by introducing the sequence string or the FASTA file with only one sequence. Hits will be extracted in a XML file in the same folder as the script.

from Bio import SeqIO
from Bio.Blast import NCBIWWW
my_query = open("sequence.fasta").read()
result_handle = NCBIWWW.qblast("blastn", "nr", my_query, word_size=7,
                                gapcosts='5 2',nucl_reward=1,nucl_penalty='-3',expect=1000)  #Parameters optimized for query short sequences
blast_result = open("my_blast.xml", "w")
blast_result.write(result_handle.read())
blast_result.close()
result_handle.close()

#We can parse through the result_handle by creating the blast_records object: 
#from Bio.Blast import NCBIXML
#blast_records = NCBIXML.parse(result_handle)
